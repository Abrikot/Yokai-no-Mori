D�velopp� par Maxence Cornaton sous Qt5.6.
-----------------------------------------------------------------------------------------------------
Pensez � installer la police (shanghai.ttf) pr�sente � la racine du dossier avant de lancer le jeu !